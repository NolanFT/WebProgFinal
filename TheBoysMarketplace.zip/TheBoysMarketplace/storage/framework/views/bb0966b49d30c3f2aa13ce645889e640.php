<style>
    .tb-category-dropdown {
        display: grid;
        grid-auto-flow: column;
        grid-template-rows: repeat(5, auto);
        padding-top: 0.25rem;
        padding-bottom: 0.25rem;
    }

    .tb-category-dropdown .dropdown-item {
        white-space: nowrap;
    }
</style>

<header class="tb-header-fixed">
    <div class="tb-container">
        <?php
            use Illuminate\Support\Str;

            $loggedIn = session('user_id') !== null;
            $userSlug = $loggedIn ? Str::slug(session('name')) : null;
            $isAdmin  = $loggedIn && session('role') === 'admin';

            $onAdminContext = request()->is('a/*');
            $onUserContext  = request()->is('u/*');

            if ($onAdminContext && $loggedIn && $userSlug) {
                $searchBaseUrl = url('/a/'.$userSlug);
            } elseif ($onUserContext && $loggedIn && $userSlug) {
                $searchBaseUrl = url('/u/'.$userSlug);
            } else {
                $searchBaseUrl = url('/');
            }

            if ($loggedIn && $userSlug) {
                if ($onUserContext) {
                    $logoHref = route('home.user', ['username' => $userSlug]);
                } elseif ($onAdminContext) {
                    $logoHref = route('admin.user', ['username' => $userSlug]);
                } else {
                    $logoHref = $isAdmin
                        ? route('admin.user', ['username' => $userSlug])
                        : route('home.user', ['username' => $userSlug]);
                }
            } else {
                // guest
                $logoHref = route('home');
            }
        ?>

        
        <a href="<?php echo e($logoHref); ?>" class="d-inline-flex align-items-center" style="gap:0.5rem;">
            <img
                src="<?php echo e(asset('images/theboys_logo.jpg')); ?>"
                alt="The Boys Logo"
                style="height:42px;width:auto;border-radius:0.4rem;object-fit:cover;background:#0f172a;"
            >
        </a>

        <div class="d-flex flex-wrap align-items-center justify-content-between" style="gap:0.75rem;">

            
            <div class="d-flex flex-grow-1 align-items-center" style="gap:0.5rem;max-width:620px;min-width:260px;">

                
                <form action="<?php echo e($searchBaseUrl); ?>" method="GET" class="d-flex flex-grow-1" style="gap:0.4rem;">
                    <?php if(request('category')): ?>
                        <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
                    <?php endif; ?>

                    <input
                        type="text"
                        name="q"
                        value="<?php echo e(request('q')); ?>"
                        class="tb-input-rounded"
                        placeholder="Search for products..."
                        style="
                            padding-left:1rem;
                            width: 480px;
                            max-width: 100%;
                        "
                    >

                    <button type="submit" class="tb-btn-primary d-inline-flex align-items-center">
                        <img
                            src="<?php echo e(asset('images/search_icon.png')); ?>"
                            alt="Search"
                            style="height:15px;width:15px;opacity:0.9;margin-right:0.3rem;"
                        >
                    </button>
                </form>

                
                <?php
                    $showFilter = request()->routeIs(
                        'home',
                        'home.user',
                        'admin.user',
                        'cart'
                    );

                    $clearCategoryUrl = request('q')
                        ? $searchBaseUrl.'?q='.urlencode(request('q'))
                        : $searchBaseUrl;
                ?>

                <?php if($showFilter): ?>
                    <div class="dropdown">
                        <button
                            type="button"
                            class="tb-pill-link dropdown-toggle d-inline-flex align-items-center"
                            id="filterDropdown"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="border:1px solid rgba(148,163,184,0.5);white-space:nowrap;"
                        >
                            <img
                                src="<?php echo e(asset('images/filter_icon.png')); ?>"
                                alt="Filter"
                                style="height:16px;width:16px;opacity:0.85;margin-right:0.35rem;"
                            >
                            Categories
                        </button>

                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="filterDropdown">
                            <?php if(request('category')): ?>
                                <li>
                                    <a class="dropdown-item text-danger fw-semibold" href="<?php echo e($clearCategoryUrl); ?>">
                                        Clear
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>

                            <li>
                                <div class="tb-category-dropdown">
                                    <?php $__currentLoopData = ($categories ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $queryString = request('q') ? '&q=' . urlencode(request('q')) : '';
                                            $catUrl      = $searchBaseUrl.'?category='.$cat['id'].$queryString;
                                        ?>

                                        <a class="dropdown-item" href="<?php echo e($catUrl); ?>">
                                            <?php echo e(ucfirst($cat['name'])); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>

            
            <nav class="d-flex flex-wrap align-items-center justify-content-end" style="gap:0.4rem;">

                
                <?php if($loggedIn): ?>
                    <?php if($onAdminContext): ?>
                        <a href="<?php echo e(route('admin.user', ['username' => $userSlug])); ?>"
                        class="tb-pill-link d-inline-flex align-items-center"
                        style="gap:0.35rem;">
                            <img src="<?php echo e(asset('images/home_icon.png')); ?>" alt="Home" style="height:16px;width:16px;opacity:0.85;">
                            Home
                        </a>
                    <?php elseif($onUserContext): ?>
                        <a href="<?php echo e(route('home.user', ['username' => $userSlug])); ?>"
                        class="tb-pill-link d-inline-flex align-items-center"
                        style="gap:0.35rem;">
                            <img src="<?php echo e(asset('images/home_icon.png')); ?>" alt="Home" style="height:16px;width:16px;opacity:0.85;">
                            Home
                        </a>
                    <?php else: ?>
                        <?php if($isAdmin): ?>
                            <a href="<?php echo e(route('admin.user', ['username' => $userSlug])); ?>"
                            class="tb-pill-link d-inline-flex align-items-center"
                            style="gap:0.35rem;">
                                <img src="<?php echo e(asset('images/home_icon.png')); ?>" alt="Home" style="height:16px;width:16px;opacity:0.85;">
                                Home
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('home.user', ['username' => $userSlug])); ?>"
                            class="tb-pill-link d-inline-flex align-items-center"
                            style="gap:0.35rem;">
                                <img src="<?php echo e(asset('images/home_icon.png')); ?>" alt="Home" style="height:16px;width:16px;opacity:0.85;">
                                Home
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>"
                    class="tb-pill-link d-inline-flex align-items-center"
                    style="gap:0.35rem;">
                        <img src="<?php echo e(asset('images/home_icon.png')); ?>" alt="Home" style="height:16px;width:16px;opacity:0.85;">
                        Home
                    </a>
                <?php endif; ?>

                
                <?php if($loggedIn && $isAdmin && str_starts_with(Route::currentRouteName(), 'admin.')): ?>
                    <a href="<?php echo e(route('admin.crud', ['username' => $userSlug])); ?>"
                    class="tb-pill-link d-inline-flex align-items-center"
                    style="gap:0.35rem;">
                        <img src="<?php echo e(asset('images/admin_icon.png')); ?>"
                            alt="Admin"
                            style="height:16px;width:16px;opacity:0.85;">
                        Admin
                    </a>
                <?php endif; ?>

                
                <?php if($loggedIn && $onUserContext): ?>
                    <a href="<?php echo e(route('cart', ['username' => $userSlug])); ?>"
                    class="tb-pill-link d-inline-flex align-items-center"
                    style="gap:0.35rem;">
                        <img src="<?php echo e(asset('images/cart_icon.png')); ?>" alt="Cart" style="height:16px;width:16px;opacity:0.85;">
                        Cart
                    </a>
                <?php elseif(!$loggedIn): ?>
                    <a href="<?php echo e(route('cart.redirect')); ?>"
                    class="tb-pill-link d-inline-flex align-items-center"
                    style="gap:0.35rem;">
                        <img src="<?php echo e(asset('images/cart_icon.png')); ?>" alt="Cart" style="height:16px;width:16px;opacity:0.85;">
                        Cart
                    </a>
                <?php endif; ?>

                
                <?php if($loggedIn): ?>
                    <?php if($onAdminContext): ?>
                        <a href="<?php echo e(route('account.admin', ['username' => $userSlug])); ?>"
                        class="tb-pill-link d-inline-flex align-items-center"
                        style="gap:0.35rem;">
                            <img src="<?php echo e(asset('images/account_icon.png')); ?>" alt="Account" style="height:16px;width:16px;opacity:0.85;">
                            Account
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('account', ['username' => $userSlug])); ?>"
                        class="tb-pill-link d-inline-flex align-items-center"
                        style="gap:0.35rem;">
                            <img src="<?php echo e(asset('images/account_icon.png')); ?>" alt="Account" style="height:16px;width:16px;opacity:0.85;">
                            Account
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                    class="tb-pill-link d-inline-flex align-items-center"
                    style="gap:0.35rem;">
                        <img src="<?php echo e(asset('images/account_icon.png')); ?>" alt="Login" style="height:16px;width:16px;opacity:0.85;">
                        Login
                    </a>
                <?php endif; ?>
            </nav>
        </div>
    </div>
</header><?php /**PATH D:\Onedrive\NolanBackUp\WindowsUsersStuff\Desktop\WebProg-main\TheBoysMarketplace\resources\views/layouts/header.blade.php ENDPATH**/ ?>