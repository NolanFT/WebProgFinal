<footer class="tb-footer">
    <div class="tb-container text-center">
        &copy; 2025 The Boys
    </div>
</footer><?php /**PATH D:\Onedrive\NolanBackUp\WindowsUsersStuff\Desktop\WebProg-main\TheBoysMarketplace\resources\views/layouts/footer.blade.php ENDPATH**/ ?>