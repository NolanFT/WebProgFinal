<?php $__env->startSection('title', 'The Boys – Home'); ?>

<?php
    use Illuminate\Support\Str;

    $userId   = session('user_id');
    $userSlug = $userId ? Str::slug(session('name')) : null;
?>

<?php $__env->startSection('content'); ?>

    <style>
        .tb-product-card {
            min-height: 340px;
            display: flex;
            flex-direction: column;
        }
    </style>

    
    <section class="mb-4">
        <div class="tb-card p-4 p-md-4" style="
            background: radial-gradient(circle at top left, var(--tb-yellow) 0, var(--tb-blue) 45%, var(--tb-black) 100%);
            color: #f9fafb;
            border: none;
        ">
            <div class="row align-items-end gy-3">
                <div class="col-md-8">
                    <span class="badge rounded-pill" style="background:#facc15;color:#111827;font-size:0.7rem;letter-spacing:0.08em;">
                        MARKETPLACE
                    </span>
                    <h1 class="mt-2 mb-2" style="font-size:1.6rem;font-weight:600;">
                        Welcome to The Boys Marketplace
                    </h1>
                </div>
            </div>
        </div>
    </section>

    
    <section class="mb-3">
        <div class="d-flex flex-wrap align-items-center justify-content-between mb-2" style="gap:0.5rem;">
            <h2 class="mb-0" style="font-size:1rem;font-weight:600;">Categories</h2>

            <div class="d-flex flex-wrap" style="gap:0.5rem;">

                <?php
                    $isAllActive = is_null($categoryId);
                ?>

                
                <?php
                    if ($userId) {
                        $allUrl = route('home.user', ['username' => $userSlug]) . ($query ? '?q=' . urlencode($query) : '');
                    } else {
                        $allUrl = url('/') . ($query ? '?q=' . urlencode($query) : '');
                    }
                ?>

                <a
                    href="<?php echo e($allUrl); ?>"
                    class="tb-pill-link"
                    style="
                        background: <?php echo e($isAllActive ? 'var(--tb-blue)' : 'rgba(15,23,42,0.06)'); ?>;
                        color: <?php echo e($isAllActive ? '#f9fafb' : '#111827'); ?>;
                        font-size:0.8rem;
                        padding:0.4rem 0.9rem;
                    "
                >
                    All
                </a>

                
                <?php $__currentLoopData = $recentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isActive = $categoryId === $cat['id'];

                        if ($userId) {
                            // logged in → keep /u/{username}
                            $catUrl = route('home.user', ['username' => $userSlug])
                                . '?category=' . $cat['id']
                                . ($query ? '&q=' . urlencode($query) : '');
                        } else {
                            // guest view
                            $catUrl = url('/?category=' . $cat['id'] . ($query ? '&q=' . urlencode($query) : ''));
                        }
                    ?>

                    <a
                        href="<?php echo e($catUrl); ?>"
                        class="tb-pill-link"
                        style="
                            background: <?php echo e($isActive ? 'var(--tb-blue)' : 'rgba(15,23,42,0.06)'); ?>;
                            color: <?php echo e($isActive ? '#f9fafb' : '#111827'); ?>;
                            font-size:0.8rem;
                            padding:0.4rem 0.9rem;
                        "
                    >
                        <?php echo e(ucfirst($cat['name'])); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php if(!is_null($categoryId) || $query): ?>
            <div style="font-size:0.8rem;color:var(--tb-gray-text);">
                <?php if(!is_null($categoryId)): ?>
                    <span>
                        Filter:
                        <strong><?php echo e(ucfirst($categoryNames[$categoryId] ?? 'Unknown')); ?></strong>
                    </span>
                <?php endif; ?>

                <?php if(!is_null($categoryId) && $query): ?>
                    <span> · </span>
                <?php endif; ?>

                <?php if($query): ?>
                    <span>Search: <strong><?php echo e($query); ?></strong></span>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </section>

    
    <section>
        <?php if($products->isEmpty()): ?>
            <div class="tb-card p-4">
                <p class="mb-0" style="font-size:0.9rem;color:var(--tb-gray-text);">
                    No products found for this filter/search.
                </p>
            </div>
        <?php else: ?>
            <div class="row g-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="tb-card tb-product-card overflow-hidden">

                            
                            <a href="<?php echo e($userId
                                    ? route('products.show.user', ['username' => $userSlug, 'id' => $product['id']])
                                    : route('products.show', $product['id'])); ?>"
                               class="ratio ratio-4x3 d-block">
                                <img
                                    src="<?php echo e($product->image_url); ?>"
                                    alt="<?php echo e($product['name']); ?>"
                                    class="w-100 h-100"
                                    style="object-fit:cover;"
                                >
                            </a>

                            <div class="p-2 p-md-3 d-flex flex-column h-100">
                                <div>
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <?php
                                            $catId = $product['category_id'];

                                            if (!is_null($catId)) {
                                                if ($userId) {
                                                    $catUrl = route('home.user', ['username' => $userSlug])
                                                        . '?category=' . $catId
                                                        . ($query ? '&q=' . urlencode($query) : '');
                                                } else {
                                                    $catUrl = url('/?category=' . $catId . ($query ? '&q=' . urlencode($query) : ''));
                                                }

                                                $catLabel = ucfirst($categoryNames[$catId] ?? 'Unknown');
                                            } else {
                                                $catUrl   = null;
                                                $catLabel = 'Uncategorized';
                                            }
                                        ?>

                                        <?php if(!is_null($catId)): ?>
                                            <a
                                                href="<?php echo e($catUrl); ?>"
                                                class="badge rounded-pill"
                                                style="background:#facc15;color:#111827;font-size:0.7rem;text-decoration:none;cursor:pointer;"
                                            >
                                                <?php echo e($catLabel); ?>

                                            </a>
                                        <?php else: ?>
                                            <span
                                                class="badge rounded-pill"
                                                style="background:#9ca3af;color:#111827;font-size:0.7rem;"
                                            >
                                                <?php echo e($catLabel); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    
                                    <h3 class="mb-1" style="font-size:0.9rem;font-weight:600;">
                                        <a href="<?php echo e($userId
                                                ? route('products.show.user', ['username' => $userSlug, 'id' => $product['id']])
                                                : route('products.show', $product['id'])); ?>"
                                           style="color:inherit;text-decoration:none;">
                                            <?php echo e($product['name']); ?>

                                        </a>
                                    </h3>

                                    <p class="mb-2" style="font-size:0.9rem;font-weight:600;color:var(--tb-blue);">
                                        Rp<?php echo e(number_format($product['price'], 0, ',', '.')); ?>

                                    </p>
                                </div>

                                <?php
                                    $isOutOfStock = ($product['quantity'] ?? 0) <= 0;
                                ?>

                                <div class="d-flex gap-2 mt-auto">
                                    <?php if($isOutOfStock): ?>
                                        <button type="button"
                                                class="tb-btn-primary w-100 text-center"
                                                disabled
                                                style="background:#9ca3af;border-color:#9ca3af;cursor:not-allowed;opacity:0.8;">
                                            Out of Stock
                                        </button>
                                    <?php else: ?>
                                        <?php if($userId): ?>
                                            <form method="POST"
                                                action="<?php echo e(route('cart.add', [
                                                    'username' => $userSlug,
                                                    'product'  => $product['id'],
                                                ])); ?>"
                                                class="flex-fill tb-add-to-cart-form"
                                                data-max="<?php echo e($product['quantity']); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="quantity" value="1">

                                                <div class="d-flex tb-add-to-cart-inactive">
                                                    <button type="button" class="tb-btn-primary w-100 tb-add-to-cart-trigger">
                                                        Add to Cart
                                                    </button>
                                                </div>

                                                <div class="d-flex align-items-center tb-add-to-cart-active d-none" style="gap:0.4rem;">
                                                    <div class="d-flex align-items-center" style="gap:0.3rem;">
                                                        <button type="button"
                                                                class="btn btn-sm"
                                                                style="border-radius:999px;border:1px solid #d1d5db;padding:0.1rem 0.5rem;"
                                                                data-role="qty-minus">
                                                            –
                                                        </button>
                                                        <div class="tb-qty-display" style="min-width:28px;text-align:center;font-weight:500;">
                                                            1
                                                        </div>
                                                        <button type="button"
                                                                class="btn btn-sm"
                                                                style="border-radius:999px;border:1px solid #d1d5db;padding:0.1rem 0.5rem;"
                                                                data-role="qty-plus">
                                                            +
                                                        </button>
                                                    </div>

                                                    <button type="submit" class="tb-btn-primary flex-grow-1 text-center">
                                                        Add to Cart
                                                    </button>
                                                </div>
                                            </form>
                                        <?php else: ?>
                                            
                                            <a href="<?php echo e(route('login')); ?>"
                                            class="tb-btn-primary w-100 text-center">
                                                Add to Cart
                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Onedrive\NolanBackUp\WindowsUsersStuff\Desktop\WebProg-main\TheBoysMarketplace\resources\views/home.blade.php ENDPATH**/ ?>