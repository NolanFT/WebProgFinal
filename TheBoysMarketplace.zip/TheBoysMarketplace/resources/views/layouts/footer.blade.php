<footer class="tb-footer">
    <div class="tb-container text-center">
        &copy; 2025 The Boys
    </div>
</footer>