<?php

return [
    'page_title' => 'Masuk - The Boys',
    'title' => 'Masuk ke akun Anda',
    'brand' => 'THE BOYS',

    'email' => 'Email',
    'email_placeholder' => 'Email Anda',

    'password' => 'Kata Sandi',
    'password_placeholder' => 'Kata Sandi Anda',

    'login_button' => 'Masuk',

    'no_account' => 'Belum punya akun?',
    'sign_up' => 'Daftar',
];
