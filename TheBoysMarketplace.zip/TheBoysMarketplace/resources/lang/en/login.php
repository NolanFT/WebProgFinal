<?php

return [
    'page_title' => 'Login - The Boys',
    'title' => 'Login to your account',
    'brand' => 'THE BOYS',

    'email' => 'Email',
    'email_placeholder' => 'Your Email',

    'password' => 'Password',
    'password_placeholder' => 'Your Password',

    'login_button' => 'Login',

    'no_account' => "Don't have an account?",
    'sign_up' => 'Sign Up',
];
